import tkinter as tk

class CarRentalSystemApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Car Rental System")
        self.master.geometry("400x300")

        self.start_label = tk.Label(self.master, text="Welcome to Car Rental System", font=("Helvetica", 18))
        self.start_label.pack(pady=20)

        self.start_button = tk.Button(self.master, text="Start", command=self.open_app_screen)
        self.start_button.pack(pady=10)

    def open_app_screen(self):
        self.start_label.destroy()
        self.start_button.destroy()

        self.app_label = tk.Label(self.master, text="Car Rental Application", font=("Helvetica", 18))
        self.app_label.pack(pady=20)

        # Add other GUI elements for the main application screen here

if __name__ == "__main__":
    root = tk.Tk()
    app = CarRentalSystemApp(root)
    root.mainloop()