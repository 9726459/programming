# Car class represents a car object
class Car:
    def __init__(self, id, make, model, year, color, mileage, available):
        self.id = id
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.mileage = mileage
        self.available = available